#ifndef TEMPLATE_SOLUTION_H
#define TEMPLATE_SOLUTION_H

#include <string>

class Solution {
public:
  bool simplePalindrome(std::string str);
  bool approximatePalindrome(std::string str);
};

#endif