#ifndef TEMPLATE_SOLUTION_H
#define TEMPLATE_SOLUTION_H

class Solution {
public:
  void swapByReference(int& x, int& y);
  void swapByPointers(int* x, int* y);
};

#endif