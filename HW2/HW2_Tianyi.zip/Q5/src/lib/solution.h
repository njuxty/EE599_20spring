#ifndef TEMPLATE_SOLUTION_H
#define TEMPLATE_SOLUTION_H

#include <string>

class Solution {
public:
  void swapChar(std::string& str, int i, int j);
  void reverse(std::string& str);
  void lowerStr(std::string& str);
};

#endif