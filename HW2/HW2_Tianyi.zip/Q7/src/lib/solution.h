#ifndef TEMPLATE_SOLUTION_H
#define TEMPLATE_SOLUTION_H

#include <string>
#include <map>
#include <unordered_map>
#include <iostream>

class Solution {
public:
  std::map<char, char> mappable(std::string str1, std::string str2);
};


#endif